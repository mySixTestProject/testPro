//
//  UITableView+XMNCellRegister.h
//  XMChatBarExample
//
//  Created by shscce on 15/11/23.
//  Copyright © 2015年 xmfraker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (XMNCellRegister)

- (void)registerXMNChatMessageCellClass;

@end
