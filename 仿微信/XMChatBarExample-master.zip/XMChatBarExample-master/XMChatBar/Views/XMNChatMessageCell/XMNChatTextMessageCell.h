//
//  XMNChatTextMessageCell.h
//  XMNChatExample
//
//  Created by shscce on 15/11/13.
//  Copyright © 2015年 xmfraker. All rights reserved.
//

#import "XMNChatMessageCell.h"

@interface XMNChatTextMessageCell : XMNChatMessageCell


@end
