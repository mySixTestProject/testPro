//
//  XMNChatSystemMessageCell.h
//  XMNChatExample
//
//  Created by shscce on 15/11/17.
//  Copyright © 2015年 xmfraker. All rights reserved.
//

#import "XMNChatMessageCell.h"

@interface XMNChatSystemMessageCell : XMNChatMessageCell

@end
