//
//  XMNChatServerExample.h
//  XMChatBarExample
//
//  Created by shscce on 15/11/23.
//  Copyright © 2015年 xmfraker. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "XMNChatServer.h"

@interface XMNChatServerExample : NSObject <XMNChatServer>

- (void)cancelTimer;

@end
