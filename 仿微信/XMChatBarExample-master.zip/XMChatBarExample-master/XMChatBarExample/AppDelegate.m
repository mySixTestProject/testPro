//
//  AppDelegate.m
//  XMChatBarExample
//
//  Created by shscce on 15/8/17.
//  Copyright (c) 2015年 xmfraker. All rights reserved.
//

#import "AppDelegate.h"

#import "RootViewController.h"


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {


    // Override point for customization after application launch.
//    RootViewController *viewC = [[RootViewController alloc] init];
//    
//    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:viewC];
//    self.window.rootViewController = nav;
//    [self.window makeKeyAndVisible];
    
    return YES;
}

@end
