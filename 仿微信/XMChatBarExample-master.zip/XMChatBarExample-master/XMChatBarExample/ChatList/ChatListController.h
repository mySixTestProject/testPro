//
//  ChatListController.h
//  SpotGoods
//
//  Created by shscce on 15/8/14.
//  Copyright (c) 2015年 shscce. All rights reserved.
//


#import <UIKit/UIKit.h>

/**
 *  显示用户的会话列表
 */
@interface ChatListController : UIViewController

@end
